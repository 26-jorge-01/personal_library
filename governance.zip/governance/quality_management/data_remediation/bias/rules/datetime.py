# datetime_bias_rules.py
import pandas as pd
import numpy as np
import logging

logger = logging.getLogger(__name__)

def reduce_temporal_skewness(series: pd.Series):
    """
    Aplica una transformación logarítmica a la diferencia en segundos entre cada fecha
    y la fecha mínima para reducir el sesgo en la distribución temporal.
    """
    try:
        s = pd.to_datetime(series.dropna(), errors='coerce')
        if s.empty:
            return series, "Serie vacía, sin transformación temporal"
        min_val = s.min()
        diff = (s - min_val).dt.total_seconds()
        diff = diff.replace(0, 1)
        log_diff = np.log(diff)
        norm = (log_diff - log_diff.min()) / (log_diff.max() - log_diff.min())
        total_range = (s.max() - min_val).total_seconds()
        transformed_seconds = norm * total_range
        transformed = min_val + pd.to_timedelta(transformed_seconds, unit='s')
        series.update(transformed)
        return series, "Transformación logarítmica aplicada para reducir sesgo temporal"
    except Exception as e:
        logger.error("Error en reduce_temporal_skewness: %s", str(e))
        return series, "Error en transformación temporal"

def cyclical_encoding(series: pd.Series):
    """
    Aplica codificación cíclica a datos temporales.
    Determina automáticamente el periodo según el número de valores únicos del componente cíclico.
    Se asume que la serie representa meses si el número de valores únicos <= 12,
    o días de la semana si <= 7; de lo contrario, se utiliza un valor por defecto (por ejemplo, 12).
    Retorna un DataFrame con dos columnas: sin y cos.
    """
    try:
        s = pd.to_datetime(series.dropna(), errors='coerce')
        # Extraer la parte cíclica; aquí se asume el mes
        values = s.dt.month
        unique_vals = values.unique()
        if len(unique_vals) <= 7:
            period = 7
        elif len(unique_vals) <= 12:
            period = 12
        else:
            period = 12  # Valor por defecto
        sin_component = np.sin(2 * np.pi * values / period)
        cos_component = np.cos(2 * np.pi * values / period)
        encoded = pd.DataFrame({"sin": sin_component, "cos": cos_component}, index=s.index)
        # Para conservar la estructura original, se podría fusionar esta información
        return encoded, f"Codificación cíclica aplicada con periodo {period}"
    except Exception as e:
        logger.error("Error en cyclical_encoding: %s", str(e))
        return series, "Error en codificación cíclica"
