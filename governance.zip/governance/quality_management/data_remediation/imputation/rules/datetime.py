import pandas as pd
import logging

logger = logging.getLogger(__name__)

def impute_mode_date(series: pd.Series):
    """
    Imputa nulos con la fecha más común (moda) de la columna.

    Args:
        series (pd.Series): Serie de pandas con los datos.

    Returns:
        pd.Series: Serie de pandas con los nulos imputados.
        str: Descripción de la acción realizada.
    """
    try:
        mode_date = series.mode().iloc[0]
    except Exception:
        mode_date = pd.Timestamp('1970-01-01')
    series.fillna(mode_date, inplace=True)
    return series, f"Imputados nulos con moda de fecha ({mode_date})"