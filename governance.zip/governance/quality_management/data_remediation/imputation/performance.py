import numpy as np
import pandas as pd
import logging

logger = logging.getLogger(__name__)

def evaluate_numeric_imputation(original_series: pd.Series, imputed_series: pd.Series):
    """
    Evalúa el desempeño de la imputación en columnas numéricas usando RMSE y MAE.
    Se comparan los valores originales (donde están presentes) con los imputados.
    """
    try:
        mask = original_series.notnull()
        diff = original_series[mask] - imputed_series[mask]
        rmse = np.sqrt(np.mean(diff**2))
        mae = np.mean(np.abs(diff))
        return {"RMSE": rmse, "MAE": mae}
    except Exception as e:
        logger.error("Error en evaluate_numeric_imputation: %s", str(e))
        return {"error": str(e)}

def evaluate_string_imputation(original_series: pd.Series, imputed_series: pd.Series):
    """
    Evalúa la imputación en columnas de texto comparando el porcentaje de coincidencia exacta.
    """
    try:
        original = original_series.dropna().astype(str)
        imputed = imputed_series.loc[original.index].astype(str)
        matches = (original == imputed).sum()
        total = len(original)
        accuracy = matches / total * 100
        return {"Accuracy": accuracy}
    except Exception as e:
        logger.error("Error en evaluate_string_imputation: %s", str(e))
        return {"error": str(e)}

def select_best_imputation(candidates: dict, inferred_type: str):
    """
    Dado un diccionario de variantes candidatas (clave: nombre, valor: (candidate_series, performance_metrics)),
    selecciona la mejor variante en función de los criterios definidos:
      - Para datos numéricos: se selecciona la variante con menor RMSE.
      - Para datos de texto: se selecciona la variante con mayor Accuracy.
    Retorna el nombre de la mejor variante y sus métricas.
    """
    best_candidate = None
    best_metric = None

    if inferred_type in ["integer", "float"]:
        for name, (series, performance) in candidates.items():
            # Si ocurre un error en la evaluación, se ignora esta variante
            if "error" in performance:
                continue
            rmse = performance.get("RMSE", np.inf)
            if best_metric is None or rmse < best_metric:
                best_metric = rmse
                best_candidate = name
    elif inferred_type == "string":
        for name, (series, performance) in candidates.items():
            if "error" in performance:
                continue
            accuracy = performance.get("Accuracy", 0)
            if best_metric is None or accuracy > best_metric:
                best_metric = accuracy
                best_candidate = name
    else:
        # Para otros tipos, se podría definir otra lógica; por ahora se retorna None.
        return None, {}

    return best_candidate, {"metric": best_metric}

def evaluate_imputation(original_series: pd.Series, imputed_series: pd.Series, inferred_type: str):
    """
    Función genérica para evaluar la imputación en función del tipo.
    """
    if inferred_type in ["integer", "float"]:
        return evaluate_numeric_imputation(original_series, imputed_series)
    elif inferred_type == "string":
        return evaluate_string_imputation(original_series, imputed_series)
    else:
        return {"info": "No se define evaluación para este tipo"}
